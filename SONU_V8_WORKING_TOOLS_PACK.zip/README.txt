SONU VIP BOOSTER V8 Working Tools — test package

1. Upload SONU_VIP_BOOSTER_V8_WORKING_TOOLS.html to GitHub repository root.
2. Back up .github/workflows/build-apk.yml and replace it with the included workflow content (rename to build-apk.yml).
3. GitHub Actions: Run workflow on main. Download the generated APK artifact and test.

Existing Supabase login code and Android native game launcher are carried forward from supplied source files; do NOT delete working app until verified.
Interactive tools: aim training, local check-in, goals, HUD planner, notes, theme accents, feature voting, local backups, and others.
Backend-required features such as leaderboards, expiry countdown, announcements, shared rewards and redemption are NOT active and require secure APIs.
No tool here modifies Free Fire game files, guarantees lag reduction, or provides in-game rewards.
